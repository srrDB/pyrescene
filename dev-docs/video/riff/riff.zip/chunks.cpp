/* chunks.cpp
*
*    List the majors chunks of a RIFF file
*
*/
#include <stdio.h>

typedef unsigned char BYTE;
typedef unsigned int DWORD;

int GetLong(char *buf);
void show_list(FILE *in, int length);

int depth = 0;

void indent()
{
	int i;
	for (i=0; i<depth; i++) printf("  ");
}

class FourCC
{
public:
	DWORD code;
	int read(FILE *in);
	bool Equals(char *str) {  return (*(DWORD *)str == code); }
	void show();
};

class Chunk
{
public:
	FourCC type;
	DWORD length;
	int read(FILE *in);
	void show();
	void skip(FILE *in);
	bool Equals(char *str) { return (*(DWORD *)str == type.code); }
};

void dump(FILE *in);

int main(int argc, char *argv[])
{
	FILE *in;
	char *filename;
	int i, iret;

	if (argc<2) {
		printf("usage: chunks filename\n");
		return -1;
	}
	filename = argv[1];
	in = fopen(filename,"rb");
	printf("filename: %s\n",filename);
	if (!in) {
		printf("file not found\n");
		return -1;
	}
	Chunk hd;
	hd.read(in);
	hd.show();
	if (hd.Equals("RIFF")) show_list(in,hd.length);
	return 0;
}

inline int GetLong(char *buf)
{
	return (*(long *)buf);
}

inline short GetShort(char *buf)
{
	return (*(short *)buf);
}

void dump(FILE *in)
{
#define BUFSIZE 96
	char buf[BUFSIZE];
	fread(buf,sizeof(char),BUFSIZE,in);
	int i, j, k;
	char cp;

	for (i=0; i<BUFSIZE; i+=4) {
		for (j=0; j<4; j++) {
			cp = buf[i+j];
			printf("%c",(cp>31?cp:'.'));
		}
		printf("  %d\n",GetLong(buf+i));
	}
}

void show_list(FILE *in, int length)
{
	int i, iret, count;
	FourCC type;
	Chunk ck;
	type.read(in);
	depth++;
	indent();
	type.show();
	count = 4; //  count includes code just read
	while (count<length) {
		iret = ck.read(in);
		if (iret) break;
		indent();
		ck.show();
		if (ck.Equals("LIST")) show_list(in, ck.length);
		else ck.skip(in);
		count += ck.length+8;
		if (ck.length&1) count++; // account for extra odd byte
	}
	depth--;
	indent();
	if (iret) printf("*** end of file (%d bytes short)***\n",length-count);
	else if (count==length) printf("-----------------\n");
	else printf("*** actual %d desired %d ***\n",count,length);
}

int Chunk::read(FILE *in)
{
	int i;
	char buf[8];
	fread(buf,sizeof(char),8,in);
	if (feof(in)) return -1;
	type.code = GetLong(buf);
	length = GetLong(buf+4);
	return 0;
}

void Chunk::skip(FILE *in)
{
	long nbytes;
	nbytes = (length&1? length+1: length); // round up to even word boundary
	fseek(in,nbytes,SEEK_CUR);
}


void Chunk::show()
{
	DWORD str[2];
	str[0] = type.code;
	str[1] = 0;
	printf("%4s  %d\n",(char *)str,length);
}

int FourCC::read(FILE *in)
{
	fread((char *) &code,sizeof(FourCC),1,in);
	return (feof(in)? -1: 0);
}

void FourCC::show()
{
	DWORD str[2];
	str[0] = code;
	str[1] = 0;
	printf("code: %s\n",(char *)str);
}
